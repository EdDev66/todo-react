module.exports = {
  trailingComma: "all",
  singleQuote: false,
  arrowParens: "always",
};
 